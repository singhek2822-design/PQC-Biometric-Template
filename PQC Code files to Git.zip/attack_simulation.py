



# Streamlined attack simulation for PQC-protected biometric templates.
# Includes: Template inversion, correlation attacks, brute force, hill climbing.


import matplotlib
matplotlib.use('Agg')

import numpy as np
import random
import sys
sys.path.append('.')  # Ensures current directory is in path


from main import Config, DataPipeline, FeatureExtractor, CancelableBiometricTemplate
# Imports classical protection system
from main_classical import generate_biohash_template

# Loads real biometric data and generate PQC-protected (cancelable) templates
config = Config()
data_pipeline = DataPipeline(config)
feature_extractor = FeatureExtractor(config)

cancelable_system = CancelableBiometricTemplate(config)


# Loads fingerprint and face data
fingerprint_data = data_pipeline.load_fingerprint_data()
face_data = data_pipeline.load_face_data()


def get_templates_for_attack():
    # This function prepares a list of templates for attack simulation.
    # Both PQC-protected and classical-protected templates are included for fingerprint and face.
    templates = []
    # PQC-protected fingerprint
    if fingerprint_data:
        fp_sample = fingerprint_data[0]
        fp_processed = data_pipeline.preprocess_image(fp_sample['image'])
        fp_features = feature_extractor.extract_fingerprint_features(fp_processed)
        fp_cancelable, _ = cancelable_system.generate_cancelable_template(fp_features, 'user_fp_001', 'app_fp')
        templates.append(('pqc_fingerprint', fp_cancelable))
        # Classical protected fingerprint
        fp_classical = generate_biohash_template(fp_features, 'user_fp_001', 'app_fp')
        templates.append(('classical_fingerprint', fp_classical))
    # PQC-protected face
    if face_data:
        face_sample = face_data[0]
        face_processed = data_pipeline.preprocess_image(face_sample['image'])
        face_features = feature_extractor.extract_face_features(face_processed)
        face_cancelable, _ = cancelable_system.generate_cancelable_template(face_features, 'user_face_001', 'app_face')
        templates.append(('pqc_face', face_cancelable))
        # Classical protected face
        face_classical = generate_biohash_template(face_features, 'user_face_001', 'app_face')
        templates.append(('classical_face', face_classical))
    return templates

cancelable_templates = get_templates_for_attack()

# 1. Template Inversion Testing
def template_inversion(template):
    # Simulates template inversion by random guessing.
    # The similarity score is calculated by comparing the guess to the template.
    guess = np.random.normal(0, 1, size=template.shape)
    score = np.mean(np.isclose(template, guess, atol=0.1))
    print(f"Template inversion score (random guess): {score:.3f}")
    return score

# 2. Correlation Attacks
def correlation_attack(template):
    # Computes the correlation between the template and a random vector.
    # This helps to check if the template leaks any linear information.
    random_vec = np.random.normal(0, 1, size=template.shape)
    corr = np.corrcoef(template, random_vec)[0, 1]
    print(f"Correlation between template and random vector: {corr:.3f}")
    return corr

# 3. Brute Force Analysis
def brute_force_attack(template, max_attempts=1000):
    # Performs a brute force attack by generating random guesses.
    # Counts how many times the guess matches the template within a tolerance.
    matches = 0
    for _ in range(max_attempts):
        guess = np.random.normal(0, 1, size=template.shape)
        if np.allclose(template, guess, atol=0.1):
            matches += 1
    print(f"Brute force matches in {max_attempts} attempts: {matches}")
    return matches

# 4. Hill Climbing Attacks
def hill_climbing_attack(template, steps=100):
    # Performs a hill climbing attack by iteratively improving a guess.
    # At each step, one value is set to the correct value from the template.
    # The best similarity score is tracked and reported.
    guess = np.random.normal(0, 1, size=template.shape)
    best_score = np.mean(np.isclose(template, guess, atol=0.1))
    for _ in range(steps):
        idx = random.randint(0, len(template)-1)
        guess[idx] = template[idx]  # Simulate climbing by setting one value
        score = np.mean(np.isclose(template, guess, atol=0.1))
        if score > best_score:
            best_score = score
    print(f"Hill climbing best score after {steps} steps: {best_score:.3f}")
    return best_score

if __name__ == "__main__":
    # Collects results for plotting
    labels = []
    inversion_scores = []
    correlation_scores = []
    brute_force_scores = []
    hill_climbing_scores = []

    for label, template in cancelable_templates:
        if label.startswith('classical_'):
            label_print = label.replace('classical_', 'Classical-Protected ').replace('_', ' ').title()
        else:
            label_print = label.replace('pqc_', 'PQC-Protected ').replace('_', ' ').title()
        print(f"\n=== Attacking {label_print} Template ===")
        # Converts bytes (classical) template to numpy array for attack functions
        if isinstance(template, bytes):
            template = np.frombuffer(template, dtype=np.uint8)
        print("--- Template Inversion ---")
        inv_score = template_inversion(template)
        print("--- Correlation Attack ---")
        corr_score = correlation_attack(template)
        print("--- Brute Force Attack ---")
        brute_score = brute_force_attack(template)
        print("--- Hill Climbing Attack ---")
        hill_score = hill_climbing_attack(template)
        labels.append(label_print)
        inversion_scores.append(inv_score)
        correlation_scores.append(corr_score)
        brute_force_scores.append(brute_score)
        hill_climbing_scores.append(hill_score)

    # Plots comparative bar graph
    import matplotlib.pyplot as plt
    x = np.arange(len(labels))
    width = 0.2
    fig, ax = plt.subplots(figsize=(12, 6))
    rects1 = ax.bar(x - 1.5*width, inversion_scores, width, label='Template Inversion', color='tan')
    rects2 = ax.bar(x - 0.5*width, correlation_scores, width, label='Correlation', color='cadetblue')
    rects3 = ax.bar(x + 0.5*width, brute_force_scores, width, label='Brute Force', color='silver')
    rects4 = ax.bar(x + 1.5*width, hill_climbing_scores, width, label='Hill Climbing', color='dimgray')
    ax.set_ylabel('Attack Score')
    ax.set_title('Comparative Attack Results on Biometric Templates')
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=20)
    ax.legend()
    plt.tight_layout()
    plt.savefig('attack_comparison.png')
    print("\nComparative attack results graph saved as 'attack_comparison.png'.")
