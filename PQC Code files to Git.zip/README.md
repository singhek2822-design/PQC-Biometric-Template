# PQC & Classical Biometric Hardening System

This repository contains my complete implementation and evaluation of a post-quantum cryptography (PQC) based biometric template protection system, along with a classical (RSA/AES) baseline for direct comparison. The code, data, and results are organized for easy review by supervisors, collaborators, or anyone interested in modern, secure, and privacy-preserving biometric authentication.

## Project Overview

- **PQC System:** Implements a full pipeline for cancelable biometric template protection using post-quantum cryptography (Kyber/ML-KEM for key exchange, Dilithium for signatures, Module-LWE fuzzy extractor for secure key generation, and advanced feature extraction for fingerprints and faces).
- **Classical System:** Provides a parallel pipeline using classical cryptography (RSA/ECDH for key exchange, RSA/ECDSA for signatures, AES for encryption, SHA-256 for hashing) for direct benchmarking and comparison.
- **Data Pipeline:** Loads and preprocesses multiple biometric datasets (fingerprint, face, LFW, NIST-SD302) for robust evaluation.
- **Feature Extraction:** Uses advanced image processing and statistical techniques to extract discriminative features from biometric images.
- **Cancelable Templates:** Supports revocable, unlinkable, and user/application-specific template transformations.
- **Comprehensive Logging:** All results, metrics, and logs are saved for reproducibility and easy comparison.
- **Comparative Evaluation:** Includes scripts to generate LaTeX tables and summary reports comparing PQC and classical systems.

## Folder Structure

```
project-root/
│
├── main.py                      # Main PQC-based biometric pipeline
├── main_classical.py            # Classical baseline pipeline
├── requirements.txt             # Python dependencies
├── data/                        # Biometric datasets (Fingerprint-FVC, Faces-ATT, Faces-LFW, NIST-SD302)
├── pqc-evaluation/              # PQC evaluation scripts, metrics, and results
├── logs/                        # Output logs for both systems
├── comparative_metrics_table.tex # LaTeX table comparing computation times
├── ... (other scripts and modules)
└── README.md                    # This file
```

## Getting Started

1. **Install Dependencies**
   - Create a virtual environment (recommended):
     ```
     python -m venv venv
     source venv/bin/activate  # On Windows: venv\Scripts\activate
     ```
   - Install required packages:
     ```
     pip install -r requirements.txt
     ```

2. **Prepare Data**
   - Place all biometric datasets in the `data/` folder as follows:
     - `data/Fingerprint-FVC/`
     - `data/Faces-ATT/`
     - `data/Faces-LFW/`
     - `data/NIST-SD302/`
   - (Sample data structure and download instructions can be provided if needed.)

3. **Run the Pipelines**
   - **PQC System:**
     ```
     python main.py
     ```
   - **Classical System:**
     ```
     python main_classical.py
     ```
   - All logs and results will be saved in the `logs/` folder.

4. **Generate Comparative Table**
   - After running both systems, a LaTeX table comparing computation times will be generated as `comparative_metrics_table.tex`.

## Key Files

- `main.py` — Main PQC-based biometric pipeline (feature extraction, Module-LWE fuzzy extractor, cancelable templates, PQC key exchange/signature, logging).
- `main_classical.py` — Classical baseline pipeline (feature extraction, BioHashing, RSA/AES, logging, MFA simulation, LaTeX table generation).
- `attack_simulation.py` — Runs advanced attack scenarios (including noise, spoofing, and adversarial attacks) on the biometric pipeline to evaluate robustness and security.
- `GAN_attack.py` — Simulates GAN-based adversarial attacks against biometric templates, testing the system's resistance to synthetic and generative threats.
- `metrics_PQCProtected_data.py` — Computes FAR, FRR, and AUC for PQC-protected templates, similar to fixed_pqc_evaluation.py but with additional testing under noise
- `requirements.txt` — All required Python packages.
- `data/` — All biometric datasets (not included in repo, see above).
- `pqc-evaluation/` — Additional scripts, metrics, and results for PQC evaluation.
- `logs/` — Output logs for both systems.
- `comparative_metrics_table.tex` — LaTeX table for direct comparison.

## Notes for Supervisor(Bharath)

- The code is fully documented and commented in my own style for clarity and transparency.
- All results are reproducible; logs and metrics are saved for every run.
- Both PQC and classical systems use the same data and feature extraction for fair benchmarking.
- The project is modular and can be extended for further research or evaluation.

## Contact

For any questions, clarifications, or further details, please contact:

- Ekta Singh
- ekta.singh@warwick.ac.uk

---

Thank you for reviewing my work!
